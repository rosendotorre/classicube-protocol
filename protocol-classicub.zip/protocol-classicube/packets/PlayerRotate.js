/**
 * Packet 0x0B - Player Rotate (Server -> Client)
 *
 * Cambio de orientacion SIN movimiento de posicion.
 * Mas eficiente que PlayerUpdate cuando el jugador solo gira en sitio.
 *
 * Layout:
 *   Byte  - Packet ID (0x0B)
 *   SByte - Player ID
 *   Byte  - Yaw   (0-255 = 0-360 grados)
 *   Byte  - Pitch (0-255 = 0-360 grados)
 *
 * Total: 4 bytes
 */

const { BinaryWriter, BinaryReader } = require('../Binary');
const PacketIDs = require('../PacketIDs');

/**
 * @param {object} opts
 * @param {number} opts.playerId
 * @param {number} opts.yaw   - 0-255
 * @param {number} opts.pitch - 0-255
 */
function serialize({ playerId, yaw, pitch }) {
  return new BinaryWriter()
    .writeByte(PacketIDs.SERVER.PLAYER_ROTATE)
    .writeSByte(playerId)
    .writeByte(yaw & 0xFF)
    .writeByte(pitch & 0xFF)
    .toBuffer();
}

function deserialize(buf) {
  const r = new BinaryReader(buf);
  const packetId = r.readByte();
  if (packetId !== PacketIDs.SERVER.PLAYER_ROTATE) {
    throw new Error(`Expected PlayerRotate (0x0B), got 0x${packetId.toString(16)}`);
  }
  const playerId = r.readSByte();
  const yaw = r.readByte();
  const pitch = r.readByte();
  return { packetId, playerId, yaw, pitch };
}

module.exports = { serialize, deserialize, PACKET_SIZE: 4 };
