/**
 * Packet 0x00 - Player Identification (Client -> Server)
 *
 * Primer paquete que envia el cliente al conectar.
 * Layout:
 *   Byte   - Packet ID (0x00)
 *   Byte   - Protocol version (siempre 7)
 *   String - Username (64 bytes)
 *   String - Verification key (64 bytes, '-' si no hay auth)
 *   Byte   - Unused (siempre 0x00)
 *
 * Total: 131 bytes
 */

const { BinaryWriter, BinaryReader } = require('../Binary');
const PacketIDs = require('../PacketIDs');

const PROTOCOL_VERSION = 7;

/**
 * @param {object} opts
 * @param {string} opts.username
 * @param {string} [opts.verificationKey]
 */
function serialize({ username, verificationKey = '-' }) {
  return new BinaryWriter()
    .writeByte(PacketIDs.CLIENT.PLAYER_IDENTIFICATION)
    .writeByte(PROTOCOL_VERSION)
    .writeString(username)
    .writeString(verificationKey)
    .writeByte(0x00)
    .toBuffer();
}

function deserialize(buf) {
  const r = new BinaryReader(buf);
  const packetId = r.readByte();
  if (packetId !== PacketIDs.CLIENT.PLAYER_IDENTIFICATION) {
    throw new Error(`Expected PlayerIdentification (0x00), got 0x${packetId.toString(16)}`);
  }
  const protocolVersion = r.readByte();
  const username = r.readString();
  const verificationKey = r.readString();
  r.readByte(); // unused
  return { packetId, protocolVersion, username, verificationKey };
}

module.exports = { serialize, deserialize, PACKET_SIZE: 131, PROTOCOL_VERSION };
