/**
 * Packet 0x01 - Ping (Server -> Client)
 *
 * A single-byte keep-alive packet. No payload.
 * Layout:
 *   Byte - Packet ID (0x01)
 *
 * Total: 1 byte
 */

const { BinaryWriter, BinaryReader } = require('../Binary');
const PacketIDs = require('../PacketIDs');

function serialize() {
  return new BinaryWriter()
    .writeByte(PacketIDs.SERVER.PING)
    .toBuffer();
}

function deserialize(buf) {
  const r = new BinaryReader(buf);
  const packetId = r.readByte();
  if (packetId !== PacketIDs.SERVER.PING) {
    throw new Error(`Expected Ping (0x01), got 0x${packetId.toString(16)}`);
  }
  return { packetId };
}

module.exports = { serialize, deserialize, PACKET_SIZE: 1 };
