/**
 * Packet 0x04 - Level Finalize (Server -> Client)
 *
 * Sent after all LevelDataChunk packets. Gives the world dimensions.
 * Layout:
 *   Byte  - Packet ID (0x04)
 *   Short - X size (width)
 *   Short - Y size (height)
 *   Short - Z size (depth)
 *
 * Total: 7 bytes
 */

const { BinaryWriter, BinaryReader } = require('../Binary');
const PacketIDs = require('../PacketIDs');

/**
 * @param {object} opts
 * @param {number} opts.xSize
 * @param {number} opts.ySize
 * @param {number} opts.zSize
 */
function serialize({ xSize, ySize, zSize }) {
  return new BinaryWriter()
    .writeByte(PacketIDs.SERVER.LEVEL_FINALIZE)
    .writeShort(xSize)
    .writeShort(ySize)
    .writeShort(zSize)
    .toBuffer();
}

function deserialize(buf) {
  const r = new BinaryReader(buf);
  const packetId = r.readByte();
  if (packetId !== PacketIDs.SERVER.LEVEL_FINALIZE) {
    throw new Error(`Expected LevelFinalize (0x04), got 0x${packetId.toString(16)}`);
  }
  const xSize = r.readShort();
  const ySize = r.readShort();
  const zSize = r.readShort();
  return { packetId, xSize, ySize, zSize };
}

module.exports = { serialize, deserialize, PACKET_SIZE: 7 };
