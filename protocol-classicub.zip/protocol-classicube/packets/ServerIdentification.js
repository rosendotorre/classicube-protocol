/**
 * Packet 0x00 - Server Identification (Server -> Client)
 *
 * Sent immediately after client connects.
 * Layout:
 *   Byte   - Packet ID (0x00)
 *   Byte   - Protocol version (always 7)
 *   String - Server name (64 bytes)
 *   String - Server MOTD (64 bytes)
 *   Byte   - User type (0x00 = normal, 0x64 = op)
 *
 * Total: 131 bytes
 */

const { BinaryWriter, BinaryReader } = require('../Binary');
const PacketIDs = require('../PacketIDs');

const PROTOCOL_VERSION = 7;

/**
 * Serialize a ServerIdentification packet into a Buffer.
 * @param {object} opts
 * @param {string} opts.name    - Server name
 * @param {string} opts.motd    - Server MOTD
 * @param {boolean} [opts.op]  - Is the connecting player an operator?
 * @returns {Buffer}
 */
function serialize({ name, motd, op = false }) {
  return new BinaryWriter()
    .writeByte(PacketIDs.SERVER.SERVER_IDENTIFICATION)
    .writeByte(PROTOCOL_VERSION)
    .writeString(name)
    .writeString(motd)
    .writeByte(op ? 0x64 : 0x00)
    .toBuffer();
}

/**
 * Deserialize a ServerIdentification packet from a Buffer.
 * Expects the packet ID byte to already be consumed or present at offset 0.
 * @param {Buffer} buf
 * @returns {{ protocolVersion: number, name: string, motd: string, op: boolean }}
 */
function deserialize(buf) {
  const r = new BinaryReader(buf);
  const packetId = r.readByte(); // 0x00
  if (packetId !== PacketIDs.SERVER.SERVER_IDENTIFICATION) {
    throw new Error(`Expected ServerIdentification (0x00), got 0x${packetId.toString(16)}`);
  }
  const protocolVersion = r.readByte();
  const name = r.readString();
  const motd = r.readString();
  const userTypeByte = r.readByte();
  return {
    packetId,
    protocolVersion,
    name,
    motd,
    op: userTypeByte === 0x64,
  };
}

module.exports = { serialize, deserialize, PACKET_SIZE: 131 };
