/**
 * Packet 0x0E - Disconnect (Server -> Client)
 *
 * Kicks the player with a reason.
 * Layout:
 *   Byte   - Packet ID (0x0E)
 *   String - Disconnect reason (64 bytes)
 *
 * Total: 65 bytes
 */

const { BinaryWriter, BinaryReader } = require('../Binary');
const PacketIDs = require('../PacketIDs');

/**
 * @param {object} opts
 * @param {string} opts.reason
 */
function serialize({ reason }) {
  return new BinaryWriter()
    .writeByte(PacketIDs.SERVER.DISCONNECT)
    .writeString(reason)
    .toBuffer();
}

function deserialize(buf) {
  const r = new BinaryReader(buf);
  const packetId = r.readByte();
  if (packetId !== PacketIDs.SERVER.DISCONNECT) {
    throw new Error(`Expected Disconnect (0x0E), got 0x${packetId.toString(16)}`);
  }
  const reason = r.readString();
  return { packetId, reason };
}

module.exports = { serialize, deserialize, PACKET_SIZE: 65 };
