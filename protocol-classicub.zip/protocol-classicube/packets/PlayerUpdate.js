/**
 * Packet 0x09 - Player Update (Server -> Client)
 *
 * Movimiento relativo (delta) de posicion + cambio de orientacion.
 * Se usa para actualizaciones pequenas de posicion (< 4 bloques).
 * Para movimientos grandes usar PlayerTeleport (0x08).
 *
 * Los deltas son SByte en fixed-point: valor / 32
 * Rango util: -4 a +3.96875 bloques por eje.
 *
 * Layout:
 *   Byte   - Packet ID (0x09)
 *   SByte  - Player ID
 *   SByte  - Delta X (fixed-point * 32)
 *   SByte  - Delta Y (fixed-point * 32)
 *   SByte  - Delta Z (fixed-point * 32)
 *   Byte   - Yaw   (0-255)
 *   Byte   - Pitch (0-255)
 *
 * Total: 7 bytes
 */

const { BinaryWriter, BinaryReader } = require('../Binary');
const PacketIDs = require('../PacketIDs');

/**
 * @param {object} opts
 * @param {number} opts.playerId
 * @param {number} opts.dx  - Delta X en bloques (se multiplica * 32)
 * @param {number} opts.dy  - Delta Y en bloques
 * @param {number} opts.dz  - Delta Z en bloques
 * @param {number} opts.yaw   - 0-255
 * @param {number} opts.pitch - 0-255
 */
function serialize({ playerId, dx, dy, dz, yaw, pitch }) {
  return new BinaryWriter()
    .writeByte(PacketIDs.SERVER.PLAYER_UPDATE)
    .writeSByte(playerId)
    .writeSByte(Math.round(dx * 32))
    .writeSByte(Math.round(dy * 32))
    .writeSByte(Math.round(dz * 32))
    .writeByte(yaw & 0xFF)
    .writeByte(pitch & 0xFF)
    .toBuffer();
}

function deserialize(buf) {
  const r = new BinaryReader(buf);
  const packetId = r.readByte();
  if (packetId !== PacketIDs.SERVER.PLAYER_UPDATE) {
    throw new Error(`Expected PlayerUpdate (0x09), got 0x${packetId.toString(16)}`);
  }
  const playerId = r.readSByte();
  const dx = r.readSByte() / 32;
  const dy = r.readSByte() / 32;
  const dz = r.readSByte() / 32;
  const yaw = r.readByte();
  const pitch = r.readByte();
  return { packetId, playerId, dx, dy, dz, yaw, pitch };
}

module.exports = { serialize, deserialize, PACKET_SIZE: 7 };
