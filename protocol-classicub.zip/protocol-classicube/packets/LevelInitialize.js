/**
 * Packet 0x02 - Level Initialize (Server -> Client)
 *
 * Tells the client that level data is about to be sent.
 * Layout:
 *   Byte - Packet ID (0x02)
 *
 * Total: 1 byte
 */

const { BinaryWriter, BinaryReader } = require('../Binary');
const PacketIDs = require('../PacketIDs');

function serialize() {
  return new BinaryWriter()
    .writeByte(PacketIDs.SERVER.LEVEL_INITIALIZE)
    .toBuffer();
}

function deserialize(buf) {
  const r = new BinaryReader(buf);
  const packetId = r.readByte();
  if (packetId !== PacketIDs.SERVER.LEVEL_INITIALIZE) {
    throw new Error(`Expected LevelInitialize (0x02), got 0x${packetId.toString(16)}`);
  }
  return { packetId };
}

module.exports = { serialize, deserialize, PACKET_SIZE: 1 };
