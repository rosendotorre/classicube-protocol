/**
 * SetBlock packets
 *
 * There are TWO different SetBlock packets:
 *
 * --- SERVER -> CLIENT (0x06) ---
 * Tells the client a block changed.
 *   Byte  - Packet ID (0x06)
 *   Short - X
 *   Short - Y
 *   Short - Z
 *   Byte  - Block type
 * Total: 8 bytes
 *
 * --- CLIENT -> SERVER (0x05) ---
 * Client requests placing/destroying a block.
 *   Byte  - Packet ID (0x05)
 *   Short - X
 *   Short - Y
 *   Short - Z
 *   Byte  - Mode (0x00 = destroy, 0x01 = create)
 *   Byte  - Block type
 * Total: 9 bytes
 */

const { BinaryWriter, BinaryReader } = require('../Binary');
const PacketIDs = require('../PacketIDs');

// Block placement modes
const Mode = {
  DESTROY: 0x00,
  CREATE:  0x01,
};

/**
 * Server->Client: notify block change
 */
function serializeServer({ x, y, z, blockType }) {
  return new BinaryWriter()
    .writeByte(PacketIDs.SERVER.SET_BLOCK)
    .writeShort(x)
    .writeShort(y)
    .writeShort(z)
    .writeByte(blockType)
    .toBuffer();
}

function deserializeServer(buf) {
  const r = new BinaryReader(buf);
  const packetId = r.readByte();
  if (packetId !== PacketIDs.SERVER.SET_BLOCK) {
    throw new Error(`Expected SetBlock server (0x06), got 0x${packetId.toString(16)}`);
  }
  const x = r.readShort();
  const y = r.readShort();
  const z = r.readShort();
  const blockType = r.readByte();
  return { packetId, x, y, z, blockType };
}

/**
 * Client->Server: request block change
 */
function serializeClient({ x, y, z, mode, blockType }) {
  return new BinaryWriter()
    .writeByte(PacketIDs.CLIENT.SET_BLOCK)
    .writeShort(x)
    .writeShort(y)
    .writeShort(z)
    .writeByte(mode)
    .writeByte(blockType)
    .toBuffer();
}

function deserializeClient(buf) {
  const r = new BinaryReader(buf);
  const packetId = r.readByte();
  if (packetId !== PacketIDs.CLIENT.SET_BLOCK) {
    throw new Error(`Expected SetBlock client (0x05), got 0x${packetId.toString(16)}`);
  }
  const x = r.readShort();
  const y = r.readShort();
  const z = r.readShort();
  const mode = r.readByte();
  const blockType = r.readByte();
  return { packetId, x, y, z, mode, blockType };
}

module.exports = {
  Mode,
  server: { serialize: serializeServer, deserialize: deserializeServer, PACKET_SIZE: 8 },
  client: { serialize: serializeClient, deserialize: deserializeClient, PACKET_SIZE: 9 },
};
