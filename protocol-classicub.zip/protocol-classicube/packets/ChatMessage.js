/**
 * Packet 0x0D - Chat Message (bidirectional)
 *
 * Server -> Client:
 *   Player ID -1 (0xFF) = server message
 *   Other IDs = player chat
 *
 * Client -> Server:
 *   Player ID is always 0xFF (unused by server but must be sent)
 *
 * Layout:
 *   Byte   - Packet ID (0x0D)
 *   SByte  - Player ID
 *   String - Message (64 bytes)
 *
 * Total: 66 bytes
 */

const { BinaryWriter, BinaryReader } = require('../Binary');
const PacketIDs = require('../PacketIDs');

const SERVER_MESSAGE_ID = -1;

/**
 * @param {object} opts
 * @param {number} opts.playerId  - -1 for server, player ID otherwise
 * @param {string} opts.message
 */
function serialize({ playerId = SERVER_MESSAGE_ID, message }) {
  return new BinaryWriter()
    .writeByte(PacketIDs.SERVER.CHAT_MESSAGE)
    .writeSByte(playerId)
    .writeString(message)
    .toBuffer();
}

function deserialize(buf) {
  const r = new BinaryReader(buf);
  const packetId = r.readByte();
  if (packetId !== PacketIDs.SERVER.CHAT_MESSAGE) {
    throw new Error(`Expected ChatMessage (0x0D), got 0x${packetId.toString(16)}`);
  }
  const playerId = r.readSByte();
  const message = r.readString();
  return { packetId, playerId, message };
}

module.exports = { serialize, deserialize, PACKET_SIZE: 66, SERVER_MESSAGE_ID };
