/**
 * Packet 0x0C - Despawn Player (Server -> Client)
 *
 * Elimina la entidad de un jugador del mundo del cliente.
 * Se envia cuando un jugador se desconecta o cambia de mundo.
 *
 * Layout:
 *   Byte  - Packet ID (0x0C)
 *   SByte - Player ID
 *
 * Total: 2 bytes
 */

const { BinaryWriter, BinaryReader } = require('../Binary');
const PacketIDs = require('../PacketIDs');

/**
 * @param {object} opts
 * @param {number} opts.playerId
 */
function serialize({ playerId }) {
  return new BinaryWriter()
    .writeByte(PacketIDs.SERVER.DESPAWN_PLAYER)
    .writeSByte(playerId)
    .toBuffer();
}

function deserialize(buf) {
  const r = new BinaryReader(buf);
  const packetId = r.readByte();
  if (packetId !== PacketIDs.SERVER.DESPAWN_PLAYER) {
    throw new Error(`Expected DespawnPlayer (0x0C), got 0x${packetId.toString(16)}`);
  }
  const playerId = r.readSByte();
  return { packetId, playerId };
}

module.exports = { serialize, deserialize, PACKET_SIZE: 2 };
