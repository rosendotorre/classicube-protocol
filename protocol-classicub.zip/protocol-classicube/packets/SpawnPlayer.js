/**
 * Packet 0x07 - Spawn Player (Server -> Client)
 *
 * Spawns a player entity in the world.
 * Player ID -1 (0xFF) = the local player.
 *
 * Layout:
 *   Byte   - Packet ID (0x07)
 *   SByte  - Player ID (-1 for self)
 *   String - Player name (64 bytes)
 *   Short  - X (fixed-point: value / 32)
 *   Short  - Y (fixed-point: value / 32)
 *   Short  - Z (fixed-point: value / 32)
 *   Byte   - Yaw   (0-255 maps to 0-360°)
 *   Byte   - Pitch (0-255 maps to 0-360°)
 *
 * Total: 74 bytes
 */

const { BinaryWriter, BinaryReader } = require('../Binary');
const PacketIDs = require('../PacketIDs');

/**
 * @param {object} opts
 * @param {number} opts.playerId  - -1 for self, 0-127 for others
 * @param {string} opts.name      - Player name
 * @param {number} opts.x         - Block-space X (will be multiplied by 32)
 * @param {number} opts.y         - Block-space Y
 * @param {number} opts.z         - Block-space Z
 * @param {number} opts.yaw       - 0-255
 * @param {number} opts.pitch     - 0-255
 */
function serialize({ playerId, name, x, y, z, yaw, pitch }) {
  return new BinaryWriter()
    .writeByte(PacketIDs.SERVER.SPAWN_PLAYER)
    .writeSByte(playerId)
    .writeString(name)
    .writeShort(Math.round(x * 32))
    .writeShort(Math.round(y * 32))
    .writeShort(Math.round(z * 32))
    .writeByte(yaw & 0xFF)
    .writeByte(pitch & 0xFF)
    .toBuffer();
}

function deserialize(buf) {
  const r = new BinaryReader(buf);
  const packetId = r.readByte();
  if (packetId !== PacketIDs.SERVER.SPAWN_PLAYER) {
    throw new Error(`Expected SpawnPlayer (0x07), got 0x${packetId.toString(16)}`);
  }
  const playerId = r.readSByte();
  const name = r.readString();
  const x = r.readShort() / 32;
  const y = r.readShort() / 32;
  const z = r.readShort() / 32;
  const yaw = r.readByte();
  const pitch = r.readByte();
  return { packetId, playerId, name, x, y, z, yaw, pitch };
}

module.exports = { serialize, deserialize, PACKET_SIZE: 74 };
