/**
 * Packet 0x08 - Player Teleport (Server -> Client / Client -> Server)
 *
 * Teleports a player to an absolute position.
 * When sent by the client, Player ID is always 255 (0xFF = self).
 * When sent by the server, Player ID identifies which player to move.
 *
 * Layout:
 *   Byte   - Packet ID (0x08)
 *   SByte  - Player ID
 *   Short  - X (fixed-point * 32)
 *   Short  - Y (fixed-point * 32)
 *   Short  - Z (fixed-point * 32)
 *   Byte   - Yaw
 *   Byte   - Pitch
 *
 * Total: 10 bytes
 */

const { BinaryWriter, BinaryReader } = require('../Binary');
const PacketIDs = require('../PacketIDs');

/**
 * @param {object} opts
 * @param {number} opts.playerId
 * @param {number} opts.x
 * @param {number} opts.y
 * @param {number} opts.z
 * @param {number} opts.yaw
 * @param {number} opts.pitch
 */
function serialize({ playerId, x, y, z, yaw, pitch }) {
  return new BinaryWriter()
    .writeByte(PacketIDs.SERVER.PLAYER_TELEPORT)
    .writeSByte(playerId)
    .writeShort(Math.round(x * 32))
    .writeShort(Math.round(y * 32))
    .writeShort(Math.round(z * 32))
    .writeByte(yaw & 0xFF)
    .writeByte(pitch & 0xFF)
    .toBuffer();
}

function deserialize(buf) {
  const r = new BinaryReader(buf);
  const packetId = r.readByte();
  if (packetId !== PacketIDs.SERVER.PLAYER_TELEPORT) {
    throw new Error(`Expected PlayerTeleport (0x08), got 0x${packetId.toString(16)}`);
  }
  const playerId = r.readSByte();
  const x = r.readShort() / 32;
  const y = r.readShort() / 32;
  const z = r.readShort() / 32;
  const yaw = r.readByte();
  const pitch = r.readByte();
  return { packetId, playerId, x, y, z, yaw, pitch };
}

module.exports = { serialize, deserialize, PACKET_SIZE: 10 };
