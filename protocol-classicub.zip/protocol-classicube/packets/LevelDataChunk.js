/**
 * Packet 0x03 - Level Data Chunk (Server -> Client)
 *
 * Sends a chunk of gzipped level data.
 * The level data itself is: Int (block count) + raw block IDs,
 * all gzipped, then split into 1024-byte chunks.
 *
 * Layout:
 *   Byte      - Packet ID (0x03)
 *   Short     - Chunk length (number of meaningful bytes in this chunk, 0–1024)
 *   ByteArray - 1024 bytes of chunk data (padded with 0x00 if needed)
 *   Byte      - Percent complete (0–100)
 *
 * Total: 1028 bytes
 */

const { BinaryWriter, BinaryReader } = require('../Binary');
const PacketIDs = require('../PacketIDs');

/**
 * @param {object} opts
 * @param {Buffer} opts.chunkData    - Raw chunk bytes (up to 1024)
 * @param {number} opts.chunkLength  - Actual meaningful bytes in chunkData
 * @param {number} opts.percent      - 0-100 completion percent
 */
function serialize({ chunkData, chunkLength, percent }) {
  return new BinaryWriter()
    .writeByte(PacketIDs.SERVER.LEVEL_DATA_CHUNK)
    .writeShort(chunkLength)
    .writeByteArray(chunkData)
    .writeByte(percent)
    .toBuffer();
}

function deserialize(buf) {
  const r = new BinaryReader(buf);
  const packetId = r.readByte();
  if (packetId !== PacketIDs.SERVER.LEVEL_DATA_CHUNK) {
    throw new Error(`Expected LevelDataChunk (0x03), got 0x${packetId.toString(16)}`);
  }
  const chunkLength = r.readShort();
  const chunkData = r.readByteArray();
  const percent = r.readByte();
  return { packetId, chunkLength, chunkData, percent };
}

module.exports = { serialize, deserialize, PACKET_SIZE: 1028 };
