/**
 * Packet 0x0A - Player Move (Server -> Client)
 *
 * Movimiento relativo (delta) de posicion SIN cambio de orientacion.
 * Mas eficiente que PlayerUpdate cuando el jugador no gira.
 *
 * Los deltas son SByte en fixed-point: valor / 32
 *
 * Layout:
 *   Byte   - Packet ID (0x0A)
 *   SByte  - Player ID
 *   SByte  - Delta X (fixed-point * 32)
 *   SByte  - Delta Y (fixed-point * 32)
 *   SByte  - Delta Z (fixed-point * 32)
 *
 * Total: 5 bytes
 */

const { BinaryWriter, BinaryReader } = require('../Binary');
const PacketIDs = require('../PacketIDs');

/**
 * @param {object} opts
 * @param {number} opts.playerId
 * @param {number} opts.dx
 * @param {number} opts.dy
 * @param {number} opts.dz
 */
function serialize({ playerId, dx, dy, dz }) {
  return new BinaryWriter()
    .writeByte(PacketIDs.SERVER.PLAYER_MOVE)
    .writeSByte(playerId)
    .writeSByte(Math.round(dx * 32))
    .writeSByte(Math.round(dy * 32))
    .writeSByte(Math.round(dz * 32))
    .toBuffer();
}

function deserialize(buf) {
  const r = new BinaryReader(buf);
  const packetId = r.readByte();
  if (packetId !== PacketIDs.SERVER.PLAYER_MOVE) {
    throw new Error(`Expected PlayerMove (0x0A), got 0x${packetId.toString(16)}`);
  }
  const playerId = r.readSByte();
  const dx = r.readSByte() / 32;
  const dy = r.readSByte() / 32;
  const dz = r.readSByte() / 32;
  return { packetId, playerId, dx, dy, dz };
}

module.exports = { serialize, deserialize, PACKET_SIZE: 5 };
