/**
 * Packet 0x0F - Update User Type (Server -> Client)
 *
 * Actualiza los permisos del jugador en tiempo real.
 * Usado para dar/quitar rango de operador sin reconectar.
 *
 * User type values:
 *   0x00 = jugador normal
 *   0x64 = operador (puede borrar bloques de bedrock, etc.)
 *
 * Layout:
 *   Byte - Packet ID (0x0F)
 *   Byte - User type (0x00 normal | 0x64 op)
 *
 * Total: 2 bytes
 */

const { BinaryWriter, BinaryReader } = require('../Binary');
const PacketIDs = require('../PacketIDs');

const UserType = {
  NORMAL:   0x00,
  OPERATOR: 0x64,
};

/**
 * @param {object} opts
 * @param {boolean} opts.op - true = operador, false = normal
 */
function serialize({ op }) {
  return new BinaryWriter()
    .writeByte(PacketIDs.SERVER.UPDATE_USER_TYPE)
    .writeByte(op ? UserType.OPERATOR : UserType.NORMAL)
    .toBuffer();
}

function deserialize(buf) {
  const r = new BinaryReader(buf);
  const packetId = r.readByte();
  if (packetId !== PacketIDs.SERVER.UPDATE_USER_TYPE) {
    throw new Error(`Expected UpdateUserType (0x0F), got 0x${packetId.toString(16)}`);
  }
  const userType = r.readByte();
  return {
    packetId,
    userType,
    op: userType === UserType.OPERATOR,
  };
}

module.exports = { serialize, deserialize, PACKET_SIZE: 2, UserType };
