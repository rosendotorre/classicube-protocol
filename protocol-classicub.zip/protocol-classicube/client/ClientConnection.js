/**
 * ClientConnection
 *
 * Wraps a raw TCP socket from the client's perspective.
 * Handles framing, dispatches ALL server packets,
 * and exposes send helpers for client->server packets.
 */

const { EventEmitter } = require('events');
const net = require('net');
const PacketIDs = require('../PacketIDs');
const { BinaryWriter } = require('../Binary');

// Packet deserializers
const ServerIdentification = require('../packets/ServerIdentification');
const Ping                 = require('../packets/Ping');
const LevelInitialize      = require('../packets/LevelInitialize');
const LevelDataChunk       = require('../packets/LevelDataChunk');
const LevelFinalize        = require('../packets/LevelFinalize');
const SpawnPlayer          = require('../packets/SpawnPlayer');
const PlayerTeleport       = require('../packets/PlayerTeleport');
const PlayerUpdate         = require('../packets/PlayerUpdate');
const PlayerMove           = require('../packets/PlayerMove');
const PlayerRotate         = require('../packets/PlayerRotate');
const DespawnPlayer        = require('../packets/DespawnPlayer');
const SetBlock             = require('../packets/SetBlock');
const ChatMessage          = require('../packets/ChatMessage');
const Disconnect           = require('../packets/Disconnect');
const UpdateUserType       = require('../packets/UpdateUserType');

// Fixed packet sizes for server->client packets
const SERVER_PACKET_SIZES = {
  [PacketIDs.SERVER.SERVER_IDENTIFICATION]: 131,
  [PacketIDs.SERVER.PING]:                   1,
  [PacketIDs.SERVER.LEVEL_INITIALIZE]:        1,
  [PacketIDs.SERVER.LEVEL_DATA_CHUNK]:     1028,
  [PacketIDs.SERVER.LEVEL_FINALIZE]:          7,
  [PacketIDs.SERVER.SET_BLOCK]:               8,
  [PacketIDs.SERVER.SPAWN_PLAYER]:           74,
  [PacketIDs.SERVER.PLAYER_TELEPORT]:        10,
  [PacketIDs.SERVER.PLAYER_UPDATE]:           7,
  [PacketIDs.SERVER.PLAYER_MOVE]:             5,
  [PacketIDs.SERVER.PLAYER_ROTATE]:           4,
  [PacketIDs.SERVER.DESPAWN_PLAYER]:          2,
  [PacketIDs.SERVER.CHAT_MESSAGE]:           66,
  [PacketIDs.SERVER.DISCONNECT]:             65,
  [PacketIDs.SERVER.UPDATE_USER_TYPE]:        2,
};

class ClientConnection extends EventEmitter {
  constructor() {
    super();
    this.socket   = null;
    this._buffer  = Buffer.alloc(0);

    // Re-ensamble del level
    this._levelChunks    = [];
    this._receivingLevel = false;

    // Estado local del cliente
    this.x     = 0;
    this.y     = 0;
    this.z     = 0;
    this.yaw   = 0;
    this.pitch = 0;
    this.op    = false;

    // Entidades de otros jugadores: Map<playerId, { name, x, y, z, yaw, pitch }>
    this.players = new Map();
  }

  /**
   * Conectar a un servidor ClassiCube.
   * @param {string} host
   * @param {number} port
   * @returns {Promise<void>}
   */
  connect(host, port) {
    return new Promise((resolve, reject) => {
      this.socket = net.createConnection({ host, port }, () => resolve());
      this.socket.on('data',  (chunk) => this._onData(chunk));
      this.socket.on('close', ()      => this.emit('close'));
      this.socket.on('error', (err)   => { this.emit('error', err); reject(err); });
    });
  }

  disconnect() {
    if (this.socket && !this.socket.destroyed) this.socket.destroy();
  }

  // ──────────────────────────────────────────────
  // Framing
  // ──────────────────────────────────────────────

  _onData(chunk) {
    this._buffer = Buffer.concat([this._buffer, chunk]);

    while (this._buffer.length > 0) {
      const packetId = this._buffer[0];
      const size = SERVER_PACKET_SIZES[packetId];

      if (size === undefined) {
        this.emit('error', new Error(`Unknown server packet ID: 0x${packetId.toString(16)}`));
        this._buffer = Buffer.alloc(0);
        return;
      }

      if (this._buffer.length < size) break;

      const raw = this._buffer.slice(0, size);
      this._buffer = this._buffer.slice(size);
      this._dispatch(packetId, raw);
    }
  }

  _dispatch(packetId, buf) {
    try {
      switch (packetId) {

        case PacketIDs.SERVER.SERVER_IDENTIFICATION: {
          const pkt = ServerIdentification.deserialize(buf);
          this.op = pkt.op;
          this.emit('serverIdentification', pkt);
          break;
        }

        case PacketIDs.SERVER.PING:
          this.emit('ping');
          break;

        case PacketIDs.SERVER.LEVEL_INITIALIZE:
          this._levelChunks    = [];
          this._receivingLevel = true;
          this.emit('levelInitialize');
          break;

        case PacketIDs.SERVER.LEVEL_DATA_CHUNK: {
          const pkt = LevelDataChunk.deserialize(buf);
          if (this._receivingLevel) {
            this._levelChunks.push(pkt.chunkData.slice(0, pkt.chunkLength));
          }
          this.emit('levelDataChunk', pkt);
          break;
        }

        case PacketIDs.SERVER.LEVEL_FINALIZE: {
          const pkt      = LevelFinalize.deserialize(buf);
          const levelData = Buffer.concat(this._levelChunks);
          this._receivingLevel = false;
          this._levelChunks    = [];
          this.emit('levelFinalize', { ...pkt, levelData });
          break;
        }

        case PacketIDs.SERVER.SET_BLOCK:
          this.emit('setBlock', SetBlock.server.deserialize(buf));
          break;

        case PacketIDs.SERVER.SPAWN_PLAYER: {
          const pkt = SpawnPlayer.deserialize(buf);
          if (pkt.playerId === -1) {
            // Somos nosotros
            this.x = pkt.x; this.y = pkt.y; this.z = pkt.z;
            this.yaw = pkt.yaw; this.pitch = pkt.pitch;
          } else {
            this.players.set(pkt.playerId, {
              name: pkt.name,
              x: pkt.x, y: pkt.y, z: pkt.z,
              yaw: pkt.yaw, pitch: pkt.pitch,
            });
          }
          this.emit('spawnPlayer', pkt);
          break;
        }

        case PacketIDs.SERVER.PLAYER_TELEPORT: {
          const pkt = PlayerTeleport.deserialize(buf);
          if (pkt.playerId === -1) {
            this.x = pkt.x; this.y = pkt.y; this.z = pkt.z;
            this.yaw = pkt.yaw; this.pitch = pkt.pitch;
          } else {
            const p = this.players.get(pkt.playerId);
            if (p) {
              p.x = pkt.x; p.y = pkt.y; p.z = pkt.z;
              p.yaw = pkt.yaw; p.pitch = pkt.pitch;
            }
          }
          this.emit('playerTeleport', pkt);
          break;
        }

        case PacketIDs.SERVER.PLAYER_UPDATE: {
          const pkt = PlayerUpdate.deserialize(buf);
          const p = this.players.get(pkt.playerId);
          if (p) {
            p.x += pkt.dx; p.y += pkt.dy; p.z += pkt.dz;
            p.yaw = pkt.yaw; p.pitch = pkt.pitch;
          }
          this.emit('playerUpdate', pkt);
          break;
        }

        case PacketIDs.SERVER.PLAYER_MOVE: {
          const pkt = PlayerMove.deserialize(buf);
          const p = this.players.get(pkt.playerId);
          if (p) { p.x += pkt.dx; p.y += pkt.dy; p.z += pkt.dz; }
          this.emit('playerMove', pkt);
          break;
        }

        case PacketIDs.SERVER.PLAYER_ROTATE: {
          const pkt = PlayerRotate.deserialize(buf);
          const p = this.players.get(pkt.playerId);
          if (p) { p.yaw = pkt.yaw; p.pitch = pkt.pitch; }
          this.emit('playerRotate', pkt);
          break;
        }

        case PacketIDs.SERVER.DESPAWN_PLAYER: {
          const pkt = DespawnPlayer.deserialize(buf);
          this.players.delete(pkt.playerId);
          this.emit('despawnPlayer', pkt);
          break;
        }

        case PacketIDs.SERVER.CHAT_MESSAGE:
          this.emit('chatMessage', ChatMessage.deserialize(buf));
          break;

        case PacketIDs.SERVER.DISCONNECT: {
          const pkt = Disconnect.deserialize(buf);
          this.emit('disconnect', pkt);
          this.disconnect();
          break;
        }

        case PacketIDs.SERVER.UPDATE_USER_TYPE: {
          const pkt = UpdateUserType.deserialize(buf);
          this.op = pkt.op;
          this.emit('updateUserType', pkt);
          break;
        }

        default:
          this.emit('unknownPacket', { packetId, buf });
      }
    } catch (err) {
      this.emit('error', err);
    }
  }

  // ──────────────────────────────────────────────
  // Write helper
  // ──────────────────────────────────────────────

  _write(buf) {
    if (this.socket && !this.socket.destroyed) this.socket.write(buf);
  }

  // ──────────────────────────────────────────────
  // Send helpers - Client -> Server
  // ──────────────────────────────────────────────

  /**
   * Login handshake. Primer paquete que debe enviarse.
   * @param {object} opts
   * @param {string} opts.username
   * @param {string} [opts.verificationKey='-']
   */
  sendIdentification({ username, verificationKey = '-' }) {
    const buf = new BinaryWriter()
      .writeByte(PacketIDs.CLIENT.PLAYER_IDENTIFICATION)
      .writeByte(7) // protocol version
      .writeString(username)
      .writeString(verificationKey)
      .writeByte(0x00) // unused
      .toBuffer();
    this._write(buf);
  }

  /**
   * @param {object} opts
   * @param {number} opts.x
   * @param {number} opts.y
   * @param {number} opts.z
   * @param {number} opts.mode      - 0 = destruir, 1 = colocar
   * @param {number} opts.blockType - ID del bloque
   */
  sendSetBlock({ x, y, z, mode, blockType }) {
    this._write(SetBlock.client.serialize({ x, y, z, mode, blockType }));
  }

  /**
   * Actualiza la posicion del cliente en el servidor.
   */
  sendTeleport({ x, y, z, yaw = 0, pitch = 0 }) {
    // playerId = -1 (self) cuando el cliente envia su propia posicion
    this._write(PlayerTeleport.serialize({ playerId: -1, x, y, z, yaw, pitch }));
    this.x = x; this.y = y; this.z = z;
    this.yaw = yaw; this.pitch = pitch;
  }

  sendChat(message) {
    this._write(ChatMessage.serialize({ playerId: -1, message }));
  }
}

module.exports = ClientConnection;
