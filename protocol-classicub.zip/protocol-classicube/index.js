/**
 * classicube-protocol
 *
 * Implementacion completa del protocolo ClassiCube / Classic Minecraft.
 * Protocol version 7. Sin dependencias externas. Node.js 14+.
 */

'use strict';

const PacketIDs                        = require('./PacketIDs');
const { BinaryWriter, BinaryReader }   = require('./Binary');
const ServerConnection                 = require('./server/ServerConnection');
const ClientConnection                 = require('./client/ClientConnection');

// Packets
const PlayerIdentification = require('./packets/PlayerIdentification');
const ServerIdentification = require('./packets/ServerIdentification');
const Ping                 = require('./packets/Ping');
const LevelInitialize      = require('./packets/LevelInitialize');
const LevelDataChunk       = require('./packets/LevelDataChunk');
const LevelFinalize        = require('./packets/LevelFinalize');
const SpawnPlayer          = require('./packets/SpawnPlayer');
const PlayerTeleport       = require('./packets/PlayerTeleport');
const PlayerUpdate         = require('./packets/PlayerUpdate');
const PlayerMove           = require('./packets/PlayerMove');
const PlayerRotate         = require('./packets/PlayerRotate');
const DespawnPlayer        = require('./packets/DespawnPlayer');
const SetBlock             = require('./packets/SetBlock');
const ChatMessage          = require('./packets/ChatMessage');
const Disconnect           = require('./packets/Disconnect');
const UpdateUserType       = require('./packets/UpdateUserType');

module.exports = {
  // Utilidades core
  PacketIDs,
  BinaryWriter,
  BinaryReader,

  // Conexiones de alto nivel
  ServerConnection,
  ClientConnection,

  // Todos los paquetes
  packets: {
    PlayerIdentification,
    ServerIdentification,
    Ping,
    LevelInitialize,
    LevelDataChunk,
    LevelFinalize,
    SpawnPlayer,
    PlayerTeleport,
    PlayerUpdate,
    PlayerMove,
    PlayerRotate,
    DespawnPlayer,
    SetBlock,
    ChatMessage,
    Disconnect,
    UpdateUserType,
  },
};
