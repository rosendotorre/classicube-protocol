/**
 * ClassiCube Protocol - Binary Read/Write Helpers
 *
 * Classic protocol types:
 *   Byte      - 1 byte unsigned
 *   SByte     - 1 byte signed
 *   Short     - 2 bytes signed big-endian
 *   Int       - 4 bytes signed big-endian
 *   String    - 64 bytes, padded with spaces (0x20), ASCII
 *   ByteArray - 1024 bytes of raw data
 *   FByte     - Fixed-point: value / 32 for positions
 */

class BinaryWriter {
  constructor() {
    this._chunks = [];
    this.length = 0;
  }

  writeByte(value) {
    const buf = Buffer.alloc(1);
    buf.writeUInt8(value & 0xFF, 0);
    this._chunks.push(buf);
    this.length += 1;
    return this;
  }

  writeSByte(value) {
    const buf = Buffer.alloc(1);
    buf.writeInt8(value, 0);
    this._chunks.push(buf);
    this.length += 1;
    return this;
  }

  writeShort(value) {
    const buf = Buffer.alloc(2);
    buf.writeInt16BE(value, 0);
    this._chunks.push(buf);
    this.length += 2;
    return this;
  }

  writeInt(value) {
    const buf = Buffer.alloc(4);
    buf.writeInt32BE(value, 0);
    this._chunks.push(buf);
    this.length += 4;
    return this;
  }

  /**
   * Classic string: always 64 bytes, space-padded
   */
  writeString(value) {
    const buf = Buffer.alloc(64, 0x20); // fill with spaces
    const encoded = Buffer.from(String(value).substring(0, 64), 'ascii');
    encoded.copy(buf, 0);
    this._chunks.push(buf);
    this.length += 64;
    return this;
  }

  /**
   * ByteArray: always 1024 bytes
   */
  writeByteArray(data) {
    const buf = Buffer.alloc(1024, 0x00);
    if (Buffer.isBuffer(data)) {
      data.copy(buf, 0, 0, Math.min(data.length, 1024));
    }
    this._chunks.push(buf);
    this.length += 1024;
    return this;
  }

  /**
   * Fixed-point position byte: value * 32
   */
  writeFByte(value) {
    return this.writeSByte(Math.round(value * 32));
  }

  toBuffer() {
    return Buffer.concat(this._chunks);
  }
}

class BinaryReader {
  constructor(buffer) {
    this._buf = buffer;
    this._offset = 0;
  }

  get bytesLeft() {
    return this._buf.length - this._offset;
  }

  readByte() {
    const val = this._buf.readUInt8(this._offset);
    this._offset += 1;
    return val;
  }

  readSByte() {
    const val = this._buf.readInt8(this._offset);
    this._offset += 1;
    return val;
  }

  readShort() {
    const val = this._buf.readInt16BE(this._offset);
    this._offset += 2;
    return val;
  }

  readInt() {
    const val = this._buf.readInt32BE(this._offset);
    this._offset += 4;
    return val;
  }

  /**
   * Classic string: read 64 bytes, trim trailing spaces
   */
  readString() {
    const buf = this._buf.slice(this._offset, this._offset + 64);
    this._offset += 64;
    return buf.toString('ascii').trimEnd();
  }

  /**
   * ByteArray: read 1024 bytes
   */
  readByteArray() {
    const buf = this._buf.slice(this._offset, this._offset + 1024);
    this._offset += 1024;
    return Buffer.from(buf);
  }

  /**
   * Fixed-point position byte: raw / 32
   */
  readFByte() {
    return this.readSByte() / 32;
  }
}

module.exports = { BinaryWriter, BinaryReader };
