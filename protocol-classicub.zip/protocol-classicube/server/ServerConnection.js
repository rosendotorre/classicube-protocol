/**
 * ServerConnection
 *
 * Wraps a raw TCP socket from the server's perspective.
 * Handles framing (ClassiCube uses fixed-size packets, no length prefix),
 * dispatches incoming client packets, and exposes send helpers.
 */

const { EventEmitter } = require('events');
const PacketIDs = require('../PacketIDs');
const { BinaryReader } = require('../Binary');

// Packets - server -> client
const ServerIdentification = require('../packets/ServerIdentification');
const Ping                 = require('../packets/Ping');
const LevelInitialize      = require('../packets/LevelInitialize');
const LevelDataChunk       = require('../packets/LevelDataChunk');
const LevelFinalize        = require('../packets/LevelFinalize');
const SpawnPlayer          = require('../packets/SpawnPlayer');
const PlayerTeleport       = require('../packets/PlayerTeleport');
const PlayerUpdate         = require('../packets/PlayerUpdate');
const PlayerMove           = require('../packets/PlayerMove');
const PlayerRotate         = require('../packets/PlayerRotate');
const DespawnPlayer        = require('../packets/DespawnPlayer');
const SetBlock             = require('../packets/SetBlock');
const ChatMessage          = require('../packets/ChatMessage');
const Disconnect           = require('../packets/Disconnect');
const UpdateUserType       = require('../packets/UpdateUserType');

// Fixed packet sizes for client->server packets
const CLIENT_PACKET_SIZES = {
  [PacketIDs.CLIENT.PLAYER_IDENTIFICATION]: 131,
  [PacketIDs.CLIENT.SET_BLOCK]:              9,
  [PacketIDs.CLIENT.PLAYER_TELEPORT]:       10,
  [PacketIDs.CLIENT.CHAT_MESSAGE]:          66,
};

class ServerConnection extends EventEmitter {
  /**
   * @param {import('net').Socket} socket
   */
  constructor(socket) {
    super();
    this.socket = socket;
    this._buffer = Buffer.alloc(0);

    // Estado del jugador
    this.id    = null;
    this.name  = null;
    this.x     = 0;
    this.y     = 0;
    this.z     = 0;
    this.yaw   = 0;
    this.pitch = 0;
    this.op    = false;

    socket.on('data',  (chunk) => this._onData(chunk));
    socket.on('close', ()      => this.emit('close'));
    socket.on('error', (err)   => this.emit('error', err));
  }

  // ──────────────────────────────────────────────
  // Framing
  // ──────────────────────────────────────────────

  _onData(chunk) {
    this._buffer = Buffer.concat([this._buffer, chunk]);

    while (this._buffer.length > 0) {
      const packetId = this._buffer[0];
      const size = CLIENT_PACKET_SIZES[packetId];

      if (size === undefined) {
        this.emit('error', new Error(`Unknown client packet ID: 0x${packetId.toString(16)}`));
        this._buffer = Buffer.alloc(0);
        return;
      }

      if (this._buffer.length < size) break;

      const raw = this._buffer.slice(0, size);
      this._buffer = this._buffer.slice(size);
      this._dispatch(packetId, raw);
    }
  }

  _dispatch(packetId, buf) {
    try {
      switch (packetId) {
        case PacketIDs.CLIENT.PLAYER_IDENTIFICATION: {
          const r = new BinaryReader(buf);
          r.readByte(); // packet id
          const protocolVersion  = r.readByte();
          const username         = r.readString();
          const verificationKey  = r.readString();
          r.readByte(); // unused
          this.name = username;
          this.emit('playerIdentification', { protocolVersion, username, verificationKey });
          break;
        }

        case PacketIDs.CLIENT.SET_BLOCK: {
          const pkt = SetBlock.client.deserialize(buf);
          this.emit('setBlock', pkt);
          break;
        }

        case PacketIDs.CLIENT.PLAYER_TELEPORT: {
          const pkt = PlayerTeleport.deserialize(buf);
          this.x     = pkt.x;
          this.y     = pkt.y;
          this.z     = pkt.z;
          this.yaw   = pkt.yaw;
          this.pitch = pkt.pitch;
          this.emit('playerTeleport', pkt);
          break;
        }

        case PacketIDs.CLIENT.CHAT_MESSAGE: {
          const pkt = ChatMessage.deserialize(buf);
          this.emit('chatMessage', pkt);
          break;
        }

        default:
          this.emit('unknownPacket', { packetId, buf });
      }
    } catch (err) {
      this.emit('error', err);
    }
  }

  // ──────────────────────────────────────────────
  // Write helper
  // ──────────────────────────────────────────────

  _write(buf) {
    if (!this.socket.destroyed) this.socket.write(buf);
  }

  // ──────────────────────────────────────────────
  // Send helpers - Server -> Client
  // ──────────────────────────────────────────────

  sendServerIdentification({ name, motd, op = false }) {
    this._write(ServerIdentification.serialize({ name, motd, op }));
  }

  sendPing() {
    this._write(Ping.serialize());
  }

  sendLevelInitialize() {
    this._write(LevelInitialize.serialize());
  }

  /**
   * Envia el mapa completo: LevelInitialize + N LevelDataChunks.
   * Llama a sendLevelFinalize() por separado con las dimensiones.
   * @param {Buffer} gzippedData
   */
  sendLevel(gzippedData) {
    this.sendLevelInitialize();
    const chunkSize = 1024;
    const total = gzippedData.length;
    for (let offset = 0; offset < total; offset += chunkSize) {
      const slice   = gzippedData.slice(offset, offset + chunkSize);
      const percent = Math.min(100, Math.round(((offset + chunkSize) / total) * 100));
      this._write(LevelDataChunk.serialize({
        chunkData:   slice,
        chunkLength: slice.length,
        percent,
      }));
    }
  }

  sendLevelFinalize({ xSize, ySize, zSize }) {
    this._write(LevelFinalize.serialize({ xSize, ySize, zSize }));
  }

  sendSpawnPlayer({ playerId, name, x, y, z, yaw = 0, pitch = 0 }) {
    this._write(SpawnPlayer.serialize({ playerId, name, x, y, z, yaw, pitch }));
  }

  sendTeleport({ playerId, x, y, z, yaw = 0, pitch = 0 }) {
    this._write(PlayerTeleport.serialize({ playerId, x, y, z, yaw, pitch }));
  }

  /**
   * Movimiento relativo + orientacion.
   * Para deltas mayores a ~4 bloques usa sendTeleport().
   */
  sendPlayerUpdate({ playerId, dx, dy, dz, yaw, pitch }) {
    this._write(PlayerUpdate.serialize({ playerId, dx, dy, dz, yaw, pitch }));
  }

  /** Solo delta de posicion, sin cambio de orientacion. */
  sendPlayerMove({ playerId, dx, dy, dz }) {
    this._write(PlayerMove.serialize({ playerId, dx, dy, dz }));
  }

  /** Solo cambio de orientacion, sin mover posicion. */
  sendPlayerRotate({ playerId, yaw, pitch }) {
    this._write(PlayerRotate.serialize({ playerId, yaw, pitch }));
  }

  sendDespawnPlayer({ playerId }) {
    this._write(DespawnPlayer.serialize({ playerId }));
  }

  sendSetBlock({ x, y, z, blockType }) {
    this._write(SetBlock.server.serialize({ x, y, z, blockType }));
  }

  sendChat(message, playerId = -1) {
    this._write(ChatMessage.serialize({ playerId, message }));
  }

  /** Actualiza los permisos del jugador en tiempo real. */
  sendUpdateUserType(op) {
    this.op = op;
    this._write(UpdateUserType.serialize({ op }));
  }

  sendDisconnect(reason = 'Disconnected') {
    this._write(Disconnect.serialize({ reason }));
    this.socket.end();
  }

  kick(reason = 'Kicked') {
    this.sendDisconnect(reason);
  }

  /**
   * Inicia un loop de ping automatico.
   * @param {number} [intervalMs=5000]
   * @returns {NodeJS.Timeout}
   */
  startPingLoop(intervalMs = 5000) {
    const interval = setInterval(() => {
      if (this.socket.destroyed) return clearInterval(interval);
      this.sendPing();
    }, intervalMs);
    this.once('close', () => clearInterval(interval));
    return interval;
  }
}

module.exports = ServerConnection;
